module ArtistaHelper
end
