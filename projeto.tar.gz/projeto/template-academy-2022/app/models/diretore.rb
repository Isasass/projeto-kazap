class Diretore < ApplicationRecord
end
