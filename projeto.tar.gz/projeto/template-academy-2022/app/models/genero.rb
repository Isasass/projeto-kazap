class Genero < ApplicationRecord
end
