class Filme < ApplicationRecord
end
