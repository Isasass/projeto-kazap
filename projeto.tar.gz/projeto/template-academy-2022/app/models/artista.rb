class Artista < ApplicationRecord
end
