// Entry point for the build script in your package.json
import "@hotwired/turbo-rails"
import "./controllers/application"
import * as bootstrap from "bootstrap"
