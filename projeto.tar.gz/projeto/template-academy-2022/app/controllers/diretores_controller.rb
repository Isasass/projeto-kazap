class DiretoresController < ApplicationController
  before_action :set_diretore, only: %i[ show edit update destroy ]

  # GET /diretores or /diretores.json
  def index
    @diretores = Diretore.all
  end

  # GET /diretores/1 or /diretores/1.json
  def show
  end

  # GET /diretores/new
  def new
    @diretore = Diretore.new
  end

  # GET /diretores/1/edit
  def edit
  end

  # POST /diretores or /diretores.json
  def create
    @diretore = Diretore.new(diretore_params)

    respond_to do |format|
      if @diretore.save
        format.html { redirect_to diretore_url(@diretore), notice: "Diretore was successfully created." }
        format.json { render :show, status: :created, location: @diretore }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @diretore.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /diretores/1 or /diretores/1.json
  def update
    respond_to do |format|
      if @diretore.update(diretore_params)
        format.html { redirect_to diretore_url(@diretore), notice: "Diretore was successfully updated." }
        format.json { render :show, status: :ok, location: @diretore }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @diretore.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /diretores/1 or /diretores/1.json
  def destroy
    @diretore.destroy

    respond_to do |format|
      format.html { redirect_to diretores_url, notice: "Diretore was successfully destroyed." }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_diretore
      @diretore = Diretore.find(params[:id])
    end

    # Only allow a list of trusted parameters through.
    def diretore_params
      params.require(:diretore).permit(:nome, :criado_em)
    end
end
