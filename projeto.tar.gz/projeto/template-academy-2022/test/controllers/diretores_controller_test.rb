require "test_helper"

class DiretoresControllerTest < ActionDispatch::IntegrationTest
  setup do
    @diretore = diretores(:one)
  end

  test "should get index" do
    get diretores_url
    assert_response :success
  end

  test "should get new" do
    get new_diretore_url
    assert_response :success
  end

  test "should create diretore" do
    assert_difference("Diretore.count") do
      post diretores_url, params: { diretore: { criado_em: @diretore.criado_em, nome: @diretore.nome } }
    end

    assert_redirected_to diretore_url(Diretore.last)
  end

  test "should show diretore" do
    get diretore_url(@diretore)
    assert_response :success
  end

  test "should get edit" do
    get edit_diretore_url(@diretore)
    assert_response :success
  end

  test "should update diretore" do
    patch diretore_url(@diretore), params: { diretore: { criado_em: @diretore.criado_em, nome: @diretore.nome } }
    assert_redirected_to diretore_url(@diretore)
  end

  test "should destroy diretore" do
    assert_difference("Diretore.count", -1) do
      delete diretore_url(@diretore)
    end

    assert_redirected_to diretores_url
  end
end
