require "application_system_test_case"

class DiretoresTest < ApplicationSystemTestCase
  setup do
    @diretore = diretores(:one)
  end

  test "visiting the index" do
    visit diretores_url
    assert_selector "h1", text: "Diretores"
  end

  test "should create diretore" do
    visit diretores_url
    click_on "New diretore"

    fill_in "Criado em", with: @diretore.criado_em
    fill_in "Nome", with: @diretore.nome
    click_on "Create Diretore"

    assert_text "Diretore was successfully created"
    click_on "Back"
  end

  test "should update Diretore" do
    visit diretore_url(@diretore)
    click_on "Edit this diretore", match: :first

    fill_in "Criado em", with: @diretore.criado_em
    fill_in "Nome", with: @diretore.nome
    click_on "Update Diretore"

    assert_text "Diretore was successfully updated"
    click_on "Back"
  end

  test "should destroy Diretore" do
    visit diretore_url(@diretore)
    click_on "Destroy this diretore", match: :first

    assert_text "Diretore was successfully destroyed"
  end
end
