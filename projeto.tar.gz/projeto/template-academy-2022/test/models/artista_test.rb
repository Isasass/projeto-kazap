require "test_helper"

class ArtistaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
