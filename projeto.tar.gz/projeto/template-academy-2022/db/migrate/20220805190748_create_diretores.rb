class CreateDiretores < ActiveRecord::Migration[7.0]
  def change
    create_table :diretores do |t|
      t.string :nome
      t.string :criado_em

      t.timestamps
    end
  end
end
